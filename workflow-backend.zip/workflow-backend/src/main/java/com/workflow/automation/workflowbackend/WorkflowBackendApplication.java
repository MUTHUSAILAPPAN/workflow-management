package com.workflow.automation.workflowbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorkflowBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(WorkflowBackendApplication.class, args);
	}

}
