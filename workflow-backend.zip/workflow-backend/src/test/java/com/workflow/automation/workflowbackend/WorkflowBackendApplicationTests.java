package com.workflow.automation.workflowbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkflowBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
